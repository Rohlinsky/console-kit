# New Wordpress on docker
---
#### Description: 
Current code provide you opportunity to comfortable manage your `wp-developing`.

#### Appointment:
- For Plugins Developers
- For Themes Developers


----
##### To start create new plugin, just replace next: 
- content of file `new-plugin.php` were you find some `New Plugin` with your favorite plugin name, and your own content of creator.
- file name `new-plugin.php` in directory here `./plugins/new-plugin/new-plugin.php` with your favorite plugin name + `.php`.
- directory name `new-plugin` here `./plugins/new-plugin/` with your favorite plugin name.
- path in docker-compose file ` - ./plugins/new-plugin:/var/www/html/wp-content/plugins/new-plugin` were you find `new-plugin` twice to your favorite plugin name. 

##### To start create new child theme, just replace next: 
- content of file `/themes/twentyeleven-child/style.css` with your own content of creator
- directory name `twentyeleven-child` here `./themes/twentyeleven-child/` with your favorite child theme name.
- path in docker-compose file ` - ./themes/twentyeleven-child/:/var/www/html/wp-content/themes/twentyeleven-child` were you find `twentyeleven-child` twice 



manager markdown file https://dillinger.io/
