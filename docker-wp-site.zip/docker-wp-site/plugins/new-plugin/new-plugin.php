<?php
   /*
   Plugin Name: New Plugin
   Plugin URI: http://my-awesomeness-emporium.com
   description: A plugin to create awesomeness and spread joy
   Version: 1.2
   Author: Mr. Awesome
   Author URI: http://mrtotallyawesome.com
   License: GPL2
   */

