# Local development

- Add `127.0.0.1 site.local.com` to `/etc/hosts` file
- Run `docker-compose up` from the root of the project
- Open the app with url `site.local.com` in the browser

- List containers `docker container ls` or `docker ps`
- Connect to docker ssh `docker exec -it <container-id> sh` or `docker exec -it <container-id> bash` if this is destributive with bash includes
