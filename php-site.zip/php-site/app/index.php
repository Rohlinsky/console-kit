<?php

echo 1; 

