module.exports = (app) => {
	app.get('/*',  (req, res) => {
		res.json({
			error: 404,
			reason: "Page not found"
		})
	})
}
