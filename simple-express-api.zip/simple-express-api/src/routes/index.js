module.exports = (app) => {
  require("./root.route.js")(app),
  require("./error.route.js")(app)
}
