const express = require('express'),
	  app = express(),
	  path = require('path'),
	  public = path.join(__dirname, 'public'),
	  port = 3000

app.use('/', express.static(public))

app.get('/', (req, res) => {
  res.sendFile(path.join(public, 'index.html'))
})

app.get('/api/', (req, res) => {
  res.json({
  	status: 1
  })
})


app.listen(port, () => {
  console.log(`> App run on port ${port}`)
  console.log(`> Click on link http://localhost:${port}/`)
})
