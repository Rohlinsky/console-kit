let payload_name = '',
    is_finished = false,
    _process = {
      ready: [],
      running: ''
    }

$(document).ready(() => {
  $('[name="upload"]').click((event) => {
    // event.preventDefault()
    $('a div.glass').click()
    upload()
  })

  $('[name="payload"]').change((e) => {
    payload_name = e.target.files[0].name
  })
})

function allow_upload() {
  if (is_finished) {
    $('.btn.btn-lg.btn-secondary.back-to-upload').removeClass('btn-secondary').addClass('btn-primary')
  }

  $('.btn.btn-lg.btn-primary.back-to-upload').click(() => {
    if (is_finished) {
      showUploadPanel()
    }
  })
}
 
function upload() {
  const form = $('#add-file')[0]
  const data = new FormData(form)

  $.ajax({
    type: "POST",
    enctype: 'multipart/form-data',
    url: "/upload/" + payload_name,
    data: data,
    processData: false,
    contentType: false,
    cache: false,
    success: ({ status }) => {
      console.log(status)
      if (status) {
        $('body header h4.subtitle.payload-name i').text(payload_name)
        showResultPanel()
        run()

        let wait = setInterval(() => {
          getAppStatus()
          if (is_finished) {
            clearInterval(wait)
          }
        }, 1000 * 60)
      }
      // $("#listFiles").text(data)
    },
    error: (e) => {
      // $("#listFiles").text(e.responseText)
    }
  })
}

function getAppStatus() {
  $.ajax({
    type: "GET",
    enctype: 'multipart/form-data',
    url: "/finished/" + payload_name,
    processData: false,
    contentType: false,
    cache: false,
    success: ({ status, analize_status, analyze_info }) => {
      if (status) {
        const { ready, running } = analyze_info

        if (!analize_status && running === '') {
          is_finished = 1
          allow_upload()
        }

        if (ready && ready.length && !ready.includes(running)) {
          report()
        }
      }
      // $("#listFiles").text(data)
    },
    error: (e) => {
      // $("#listFiles").text(e.responseText)
    }
  })
}

function showUploadPanel() {
  $('div.login.upload-payload.before.analyze').removeAttr('hidden')
  $('div.login.analyze.start').attr('hidden', true)
}

function showResultPanel() {
  $('div.login.analyze.start').removeAttr('hidden')
  $('div.login.upload-payload.before.analyze').attr('hidden', true)
}


function run() {

  $.ajax({
    type: "POST",
    url: "/analyze/" + payload_name,
    processData: false,
    contentType: false,
    cache: false,
    data: {},
    success: (data) => {
      console.log(data)
    },
    error: (e) => {
      console.error(e)
    }
  })
}

function report() {

  $.ajax({
    type: "GET",
    url: "/report/" + payload_name,
    processData: false,
    contentType: false,
    cache: false,
    success: ({ status, report, description, analize_status }) => {
      // $("#listFiles").text(data)
      if (status) {
        showResult(report, analize_status)
      } else {
        console.error(description)
      }
    },
    error: (e) => {
      console.error(e)
    }
  })
}

function showResult({ name, started_at, test }, analize_status) {
  // console.log(data)
  console.log((analize_status) ? 'Bussy' : 'Ready')
  $('body header h4.subtitle.payload-name i').text(payload_name)
  $('body header h4.subtitle.status i').text((analize_status) ? 'Bussy' : 'Ready')
  const antivirus_list = Object.keys(test)
  if (antivirus_list && antivirus_list.length) {
    $('body main ul.report.list').html('')

    antivirus_list.forEach((antivirus) => {
      const { status, details } = test[antivirus]
      $('body main ul.report.list').append(`
        <li class="report item ${ antivirus + ' ' + status.toLowerCase() }">
          <h4 class='antivirus name'>${ antivirus } <b class='${status.toLowerCase()}'>${ status }</h4>
          <hr/>
          ${ (details && details.detection_type ) ? '<details>' + details.detection_type.map(item => item + '\r') + '</details>' : '' }
        </li>
      `)
    })
  }
}




// payload_name = 'virus-ducklin-html-htm'
// report('virus-ducklin-html-htm')
