const express = require('express')
const app = express()
const port = 3000
const path = require('path')
const public = path.join(__dirname, '../public')
const multer  = require('multer')
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../buffer/'))
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname)
  }
})
const fs = require('fs')
const upload = multer({ 
  storage
})

app.is_bussy = 0
app.analyze = {}

app.use('/', express.static(public))

app.get('/', (req, res) => {
  res.sendFile(path.join(public, 'index.html'))
})

app.post('/upload/:file_name', (!app.is_bussy) ? upload.single('payload') : null, (req, res) => {
  if (!app.is_bussy) {
    res.json({
      status: 1,
      data: undefined
    })

  } else {
    res.json({
      status: 0,
      detailes: 'app i bussy, upload is not ready'
    })
  }
})

app.post('/analyze/:file_name', (req, res) => {
  if (!app.is_bussy) {

    // app.is_bussy = 1
      app.is_bussy = 0
      res.json({
        status: 1,
        description: 'app is free',
        analyze: 'ready'
      })
  } else {
    app.analyze = {}
    res.json({
      status: 0,
      description: 'app is bussy'
    })
  }
})

app.get('/report/:file_name', (req, res) => {
  if (app.analyze.running && app.analyze.ready) {
    const { ready, running } = app.analyze
    if (!ready.includes(running)) {
      res.json({
        status: 1,
        report,
        analize_status: app.is_bussy
      })

    } else {
      res.json({
        status: 0,
        description: 'analyze is bussy'
      })
    }
  } else {
    try {
      res.json({
        status: 1,
        report,
        analize_status: app.is_bussy
      })

    } catch (e) {
      console.error(e)
      throw Error('Not found direcory ' + req.params.file_name)
    }
  }
})

app.get('/finished/:file_name', (req, res) => {
  res.json({
    status: 1,
    analize_status: app.is_bussy,
    analyze_info: app.analyze
  })
})

app.get('/*', (req, res) => {
  res.json({
    status: 0,
    code: 404
  })
})


app.listen(port, (err) => {
  if (err) {
    console.error(err)
    return
  }
  console.log('App running on url http://localhost:' + port)
})

